package br.com.fiap.bean;

public enum TipoConta {

	COMUM, ESPECIAL, PREMIUM
	
}