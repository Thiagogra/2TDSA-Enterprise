package br.com.fiap.revisao.bean;

public class PessoaFisica extends Pessoa {

	@Override
	public void cadastrar() {
		
	}

}