package br.com.fiap.exception;

public class CodigoInexistenteException extends Exception {

	public CodigoInexistenteException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CodigoInexistenteException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CodigoInexistenteException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CodigoInexistenteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CodigoInexistenteException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
