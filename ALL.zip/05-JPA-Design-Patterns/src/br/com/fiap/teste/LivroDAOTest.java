package br.com.fiap.teste;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.LivroDAO;
import br.com.fiap.dao.impl.LivroDAOImpl;
import br.com.fiap.entity.Genero;
import br.com.fiap.entity.Livro;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class LivroDAOTest {

	private static LivroDAO dao;

	private Livro livro;

	@BeforeAll // antes de todos os testes
	public static void init() {
		// Instanciar os objetos
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		dao = new LivroDAOImpl(em);
	}

	@BeforeEach // antes de cada teste
	public void cadastro() {
		// Cadastra um livro
		livro = new Livro("As desaventuras em s�ries", Calendar.getInstance(), Genero.AVENTURA, 600);

		try {
			dao.cadastrar(livro);
			dao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
			fail();
		}
	}

	@Test
	@DisplayName("Teste de remo��o com sucesso")
	public void remover() {

		// Remove o livro
		try {
			dao.remover(livro.getCodigo());
			dao.commit();
		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}

		// Valida o resultado
		Livro busca = dao.buscar(livro.getCodigo());

		assertNull(busca);
	}

	@Test
	@DisplayName("Teste de atualiza��o com sucesso")
	public void atualizar() {

		// Atualiza o livro
		livro.setGenero(Genero.ACAO);
		livro.setNome("O senhor dos an�is");

		try {
			dao.atualizar(livro);
			dao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
			fail();
		}

		// Busca o livro
		Livro busca = dao.buscar(livro.getCodigo());

		// Valida se foi atualizado
		assertEquals("O senhor dos an�is", busca.getNome());
		assertEquals(Genero.ACAO, busca.getGenero());
	}

	@Test
	@DisplayName("Teste de busca do DAO gen�rico")
	public void buscar() {

		// Pesquisa o livro cadastrado
		Livro busca = dao.buscar(livro.getCodigo());

		// Validar se deu certo
		assertNotNull(busca);
		assertEquals("As desaventuras em s�ries", busca.getNome());

	}

	@Test
	@DisplayName("Teste de cadastro com sucesso")
	public void cadastrar() {

		// Validar se deu certo
		assertNotEquals(0, livro.getCodigo());

	}

}
