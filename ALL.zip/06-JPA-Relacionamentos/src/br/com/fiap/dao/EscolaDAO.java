package br.com.fiap.dao;

import br.com.fiap.entity.Escola;

public interface EscolaDAO extends GenericDAO<Escola, Integer>{

}
