package br.com.fiap.dao;

import br.com.fiap.entity.Professor;

public interface ProfessorDAO extends GenericDAO<Professor, Integer>{

}
