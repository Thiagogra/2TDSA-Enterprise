package br.com.fiap.dao;

import br.com.fiap.entity.Sala;

public interface SalaDAO extends GenericDAO<Sala, Integer>{

}
