package br.com.fiap.teste;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.ClienteDAO;
import br.com.fiap.dao.EntityManagerFactorySingleton;
import br.com.fiap.dao.impl.ClienteDAOImpl;
import br.com.fiap.entity.Cliente;

class ClienteDAOTeste {

	private static ClienteDAO dao;
	
	@BeforeAll
	public static void iniciar() {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		dao = new ClienteDAOImpl(em);
	}
	
	@Test
	void buscarPorCepTest() {
		List<Cliente> lista = dao.buscarPorCEP(12220999);
		
		for (Cliente cliente : lista) {
			assertTrue(12220999 == cliente.getEndereco().getCep());
		}
	}
	
	@Test
	void buscarCpfTest() {
		List<String> cpfs = dao.buscarCpf();
		assertNotEquals(0, cpfs.size());
	}
	
	@Test
	void contarPorEstadoTest() {
		long qtd = dao.contarPorEstado("SP");
		assertEquals(1, qtd);
	}
	
	@Test
	void buscarPorNomeCidadeTest() {
		List<Cliente> lista = dao.buscar("Le", "Lo");
		for (Cliente cliente : lista) {
			assertTrue(cliente.getNome().contains("Le") && 
				cliente.getEndereco().getCidade().getNome().contains("Lo"));
		}
	}
	
	@Test
	void buscarPorEstadosTest() {
		List<String> estados = new ArrayList<String>();
		estados.add("SP");
		estados.add("PR");
		
		List<Cliente> lista = dao.buscarPorEstados(estados);
		
		for (Cliente cliente : lista) {
			assertTrue(estados.contains(cliente.getEndereco()
											.getCidade().getUf()));
		}
	}
	
	@Test
	void buscarPorDiasReserva() {
		List<Cliente> lista = dao.buscarPorDiasReserva(10);
		assertEquals(2, lista.size());		
	}
	
	@Test
	void buscarPorEstado() {
		//busca por estado e armazena na lista
		List<Cliente> lista = dao.buscarPorEstado("SP");
		//valida se os clientes s�o do estado pesquisado
		for (Cliente cliente : lista) {
			assertEquals(cliente.getEndereco().getCidade().getUf(), "SP");
		}
	}
	
	@Test
	void listar() {
		List<Cliente> lista = dao.listar();
		assertEquals(5, lista.size());
	}

	@Test
	void listarPorParteDoNome() {
		List<Cliente> lista = dao.buscarPorParteDoNome("T");
		assertEquals(1, lista.size());
		
		for (Cliente cliente : lista) {
			assertTrue(cliente.getNome().contains("T"));
			//assertNotEquals(-1, cliente.getNome().indexOf("T"));
		}
	}

}
