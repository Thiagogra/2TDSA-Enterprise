package br.com.fiap.teste;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.EntityManagerFactorySingleton;
import br.com.fiap.dao.PacoteDAO;
import br.com.fiap.dao.TransporteDAO;
import br.com.fiap.dao.impl.PacoteDAOImpl;
import br.com.fiap.dao.impl.TransporteDAOImpl;
import br.com.fiap.entity.Pacote;
import br.com.fiap.entity.Transporte;

class PacoteDAOTeste {

	private static PacoteDAO pacoteDao;
	private static TransporteDAO transporteDao;
	
	@BeforeAll
	public static void inicializar() {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		pacoteDao = new PacoteDAOImpl(em);
		transporteDao = new TransporteDAOImpl(em);
	}
	
	@Test
	void somarPrecoPorTransporteTest() {
		Transporte transporte = transporteDao.pesquisar(2);
		double soma = pacoteDao.somarPrecoPorTransporte(transporte);
		assertEquals(500, soma);
	}
	
	@Test
	void buscarPorDataTest() {
		Calendar inicio = new GregorianCalendar(2017, Calendar.JANUARY, 1);
		Calendar fim = new GregorianCalendar(2018,Calendar.JANUARY,1);
		
		List<Pacote> lista = pacoteDao.buscarPorDatas(inicio, fim);
		
		for (Pacote pacote : lista) {
			assertTrue(pacote.getDataSaida().after(inicio) && 
										pacote.getDataSaida().before(fim));
		}
	}
	
	@Test
	void buscarPorTransporteTest() {
		//busca o transporte
		Transporte transporte = transporteDao.pesquisar(1);
		//busca os pacotes por transporte
		List<Pacote> pacotes = pacoteDao.listar(transporte);
		//valida se a lista est� correta
		for (Pacote pacote : pacotes) {
			assertEquals(pacote.getTransporte().getId(), transporte.getId());
		}
	}

}






