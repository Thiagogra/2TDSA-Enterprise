package br.com.fiap.dao;

import br.com.fiap.entity.Consulta;
import br.com.fiap.entity.ConsultaPK;

public interface ConsultaDAO extends GenericDAO<Consulta, ConsultaPK> {

}
