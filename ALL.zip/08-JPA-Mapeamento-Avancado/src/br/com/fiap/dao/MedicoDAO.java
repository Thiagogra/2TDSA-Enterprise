package br.com.fiap.dao;

import br.com.fiap.entity.Medico;

public interface MedicoDAO extends GenericDAO<Medico, Integer> {

}
