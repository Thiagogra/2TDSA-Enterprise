package br.com.fiap.dao;

import br.com.fiap.entity.Paciente;

public interface PacienteDAO extends GenericDAO<Paciente, Integer> {

}
