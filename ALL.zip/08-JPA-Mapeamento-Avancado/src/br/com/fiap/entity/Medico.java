package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name = "T_MEDICO")
@SecondaryTable(name = "T_MEDICO_FINANCEIRO")
public class Medico {

	@Id

	private int codigo;

	@Column(name = "T_NOME")
	private String nome;

	@Column(name = "T_DESCRICAO")
	private String descricao;

	@Column(table = "T_MEDICO_FINANCEIRO", name = "vl_salario")
	private double salario;

	@Column(table = "T_MEDICO_FINANCEIRO", name = "nr_conta")
	private int conta;

	public Medico(int codigo, String nome, String descricao, double salario, int conta) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.descricao = descricao;
		this.salario = salario;
		this.conta = conta;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getConta() {
		return conta;
	}

	public void setConta(int conta) {
		this.conta = conta;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Medico(int codigo, String nome, String descricao) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.descricao = descricao;
	}

	public Medico(String nome, String descricao) {
		super();
		this.nome = nome;
		this.descricao = descricao;
	}

	public Medico() {
		super();
	}

}
