package br.com.fiap.teste;

import static org.junit.Assert.fail;

import java.util.Calendar;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import br.com.fiap.dao.ConsultaDAO;
import br.com.fiap.dao.EntityManagerFactorySingleton;
import br.com.fiap.dao.impl.ConsultaDAOImpl;
import br.com.fiap.entity.Consulta;
import br.com.fiap.entity.Medico;
import br.com.fiap.entity.Paciente;
import br.com.fiap.exception.CommitException;

class Teste {

	private static ConsultaDAO dao;

	@BeforeAll
	public static void init() {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		dao = new ConsultaDAOImpl(em);
	}

	@Test
	void cadastrar() {
		Medico medico = new Medico(123, "Drauzio", "Geral", 2000, 6556);
		Paciente paciente = new Paciente("Hebert", 1155656655);
		Consulta consulta = new Consulta(medico, paciente, Calendar.getInstance(), "");

		try {
			dao.cadastrar(consulta);
			dao.commit();
		} catch (CommitException e) {
			e.printStackTrace();
			fail();
		}
	}

}
