package br.com.fiap.bean;

public interface ContaInvestimento {

	double calculaRetornoInvestimento();
	
}