package br.com.fiap.entity;

public enum Nivel {

	ESTAGIO, JUNIOR, PLENO, SENIOR;
	
}
