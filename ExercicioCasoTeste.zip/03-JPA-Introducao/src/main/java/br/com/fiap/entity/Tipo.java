package br.com.fiap.entity;

public enum Tipo {

	RH, FINANCEIRO, DESENVOLVIMENTO, COMERCIAL;
	
}
