package br.com.fiap.entity;

public enum TipoFornecedor {

	ATACADO, VAREJO;
	
}
