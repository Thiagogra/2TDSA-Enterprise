package br.com.fiap.dao;

import br.com.fiap.entity.Livro;

public interface LivroDAO extends GenericDAO<Livro, Integer>{

	
}