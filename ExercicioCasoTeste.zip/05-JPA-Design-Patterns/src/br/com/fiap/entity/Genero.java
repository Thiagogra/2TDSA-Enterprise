package br.com.fiap.entity;

public enum Genero {

	ACAO, AVENTURA, ROMANCE, FICCAO, TERROR, SUSPENCE, AUTO_AJUDA;
	
}
