package br.com.fiap.dao;

import br.com.fiap.entity.Diretor;

public interface DiretorDAO extends GenericDAO<Diretor, Integer>{

}
