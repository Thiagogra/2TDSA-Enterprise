package br.com.fiap.entity;

public enum Formacao {

	GRADUACAO, ESPECIALIZACAO, MESTRADO, DOUTORADO;
	
}
