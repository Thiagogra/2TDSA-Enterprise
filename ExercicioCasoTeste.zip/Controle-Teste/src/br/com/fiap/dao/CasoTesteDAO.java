package br.com.fiap.dao;

import br.com.fiap.entity.CasoTeste;

public interface CasoTesteDAO extends GenericDAO<CasoTeste, Integer> {

}
