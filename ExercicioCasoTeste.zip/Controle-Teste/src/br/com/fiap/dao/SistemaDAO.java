package br.com.fiap.dao;

import br.com.fiap.entity.Sistema;

public interface SistemaDAO extends GenericDAO<Sistema, Integer> {

}
