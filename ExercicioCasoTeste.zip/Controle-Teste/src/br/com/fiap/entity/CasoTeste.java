package br.com.fiap.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TAB_CASO_TESTE")
@SequenceGenerator(name = "caso", sequenceName = "SQ_T_CASO", allocationSize = 1)
public class CasoTeste {

	@Id
	@Column(name = "cod_caso_teste")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "caso")
	private int codigo;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "cod_sistema", nullable = false)
	private Sistema sistema;

	@OneToMany(mappedBy = "casoteste", cascade = CascadeType.ALL)
	private List<ItemTeste> itens = new ArrayList<>();

	@Column(name = "nom_caso_teste")
	private String nome;

	@Column(name = "desc_caso_teste")
	private String descCaso;

}
